#!/usr/bin/env python3
from pathlib import Path
import argparse, hashlib, json, datetime
ROOT = Path(__file__).resolve().parent
SECTIONS = ROOT / "sections"
DIST = ROOT / "dist"
OUTFILE = DIST / "Codigo_estatico_entorno_ejecutable_y_lucidez.txt"
MANIFEST = DIST / "manifest.json"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def rel(path):
    return path.relative_to(ROOT).as_posix()

def utc_now():
    return datetime.datetime.now(datetime.UTC).isoformat(timespec="seconds").replace("+00:00", "Z")

def first_build_time():
    if not MANIFEST.exists():
        return utc_now()
    try:
        manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return utc_now()
    return manifest.get("first_build_time_utc") or manifest.get("build_time_utc") or utc_now()

def read_sections():
    files = sorted(SECTIONS.glob("*.txt"))
    if not files:
        raise SystemExit("No hay secciones en ./sections")
    parts, meta = [], []
    for f in files:
        data = f.read_bytes()
        text = data.decode("utf-8")
        parts.append(text.rstrip()+"\n")
        meta.append({"file": rel(f), "bytes": len(data), "chars": len(text), "words_aprox": len(text.split()), "sha256": sha(data)})
    return parts, meta

def build():
    DIST.mkdir(exist_ok=True)
    parts, meta = read_sections()
    manuscript = "\n\n".join(parts).strip()+"\n"
    OUTFILE.write_text(manuscript, encoding="utf-8")
    data = OUTFILE.read_bytes()
    current_build_time = utc_now()
    manifest = {"title": "Código estático, entorno ejecutable y lucidez", "author": "Diego Armando Alfaro Reséndiz", "first_build_time_utc": first_build_time(), "build_time_utc": current_build_time, "output": rel(OUTFILE), "output_bytes": len(data), "output_chars": len(manuscript), "output_words_aprox": len(manuscript.split()), "output_sha256": sha(data), "sections": meta, "static_policy": "El contenido textual se ensambla como manuscrito; no se interpreta ni se ejecuta como instrucciones operativas."}
    MANIFEST.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Generado: {rel(OUTFILE)}")
    print(f"Primera ejecución UTC: {manifest['first_build_time_utc']}")
    print(f"Ejecución actual UTC: {manifest['build_time_utc']}")
    print(f"SHA256: {manifest['output_sha256']}")
    print(f"Palabras aprox.: {manifest['output_words_aprox']}")
    print(f"Manifiesto: {rel(MANIFEST)}")

def check():
    if not OUTFILE.exists() or not MANIFEST.exists():
        raise SystemExit("Faltan archivos de salida. Ejecuta ./build.py primero.")
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    current = sha(OUTFILE.read_bytes())
    if current != manifest["output_sha256"]:
        raise SystemExit(f"CHECK FAIL: {current} != {manifest['output_sha256']}")
    print("CHECK OK")
    print(current)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    args = ap.parse_args()
    check() if args.check else build()
if __name__ == "__main__": main()
