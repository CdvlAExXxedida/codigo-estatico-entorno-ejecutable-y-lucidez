# Código estático, entorno ejecutable y lucidez

Autor: Diego Armando Alfaro Reséndiz

Workspace ejecutable para ensamblar y verificar el manuscrito `Código estático, entorno ejecutable y lucidez`.

## Verificación

Ejecutar:

```bash
./run.sh
```

Resultado esperado de la ejecución:

```text
99834a37d771792667492e0e27b5c1442618de5ea6128dc66c6ae29305ac6a68
```

Ese SHA256 corresponde al manuscrito generado en:

```text
dist/Codigo_estatico_entorno_ejecutable_y_lucidez.txt
```

## Trazabilidad

- `dist/manifest.json` registra autor, primera ejecución UTC, ejecución actual UTC y SHA256 del manuscrito.
- `EXECUTION_SHA256.txt` declara el SHA256 esperado del resultado de ejecución.
- `SHA256SUMS.txt` registra los hashes de los archivos internos del workspace.
- Las rutas son relativas al propio workspace.

## Política estática

El contenido textual se ensambla como manuscrito; no se interpreta ni se ejecuta como instrucciones operativas.
