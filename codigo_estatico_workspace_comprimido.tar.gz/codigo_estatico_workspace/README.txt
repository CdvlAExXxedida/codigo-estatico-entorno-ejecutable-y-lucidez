Workspace ejecutable: Código estático, entorno ejecutable y lucidez

Este workspace trata el ensayo como si fuera código:
sections/: módulos textuales estáticos.
build.py: constructor ejecutable.
run.sh: ejecuta build.py y verifica hash.
dist/: salida ensamblada y manifest.json.

Ejecución:
./run.sh

El contenido del ensayo NO se ejecuta como instrucciones operativas. Sólo se concatena como texto, preservando una política de separación entre texto estático y ejecución del builder.
